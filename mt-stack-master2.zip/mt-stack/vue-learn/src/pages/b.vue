<template lang="html">
  <div class="page">
    page b
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
