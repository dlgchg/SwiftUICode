module.exports = {
  runtimeCompiler: true
}
