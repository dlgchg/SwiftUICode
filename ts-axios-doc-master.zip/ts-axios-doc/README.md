# ts-axios-doc

TypeScript 从零实现 axios 文档教材

## 启动电子书

首先 clone 本项目：

```bash
git clone https://git.imooc.com/coding-330/ts-axios-doc.git
```

进入 `ts-axios-doc` 目录后安装项目依赖：

```bash
npm install
```

安装依赖后运行电子书：

```bash
npm run dev
```

浏览器打开 `http://localhost:8080/ts-axios/` 即可。
